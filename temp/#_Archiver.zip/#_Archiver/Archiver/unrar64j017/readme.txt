﻿
はじめに

    unrar32.dllをx64/ユニコード対応させた私家版です。

    動作確認は基本的に Windows7/64bit + あふw x64で行なっています。

    unrar.dllの64bit版がunrar64.dllで名前が被っていますので、
    unarj32jに倣ってunrar64j.dllになっています。

    バイナリーは https://github.com/rururutan/unrar32/releases に置いてあります。


必須要件

    unrar64jを動作させるには以下の条件を満たしている必要があります。

    64bit版Windows Vista以上
    unrar64.dll (http://www.rarlab.com/)


ライセンス

    オリジナルに従います。

    このソフトを使用または使用できないことによって生じた結果等について、
    作者は責任を負わないこととさせていただきます。


サポート

    本DLLに関し、オリジナル作者の亀井さんに問い合わせないようお願いします。
    GitHubのIssues又はTwitterのRuRuRuTanに報告してください。


変更履歴

    version 0.17 2015/6/8 (by Claybird)
      ・RuRuRu氏によるversion 0.16の変更点を取り込み
      ・開発環境をVC2005に戻した
      ・パスワード間違いによるCRCエラーのメッセージを変更した
      ・CHECKARCHIVE_NOT_ASK_PASSWORDを指定したUnrarCheckArchive()でヘッダ暗号化された
        ファイルが破損扱いになっていた不具合を修正

    version 0.16 2013/10/18 (by RuRuRu) [変更点抜粋 by Claybird]
      ・unrar.dllのAPIバージョン6(RAR5対応版)で互換性の無い変更が行われたので対応。
        これまでのバージョンでは展開に失敗する場合があります。
      ・パスワード入力時に何も入力しない場合はキャンセル扱いにした。(7-zip32準拠)
      ・環境によってはパスワード入力に失敗する不具合を修正。
      ・展開キャンセル時に即時終了する様に変更。
      ・プログレスダイアログを親ウインドウ中央に表示するように修正。
      ・128文字以上のパスワードの書庫に対応。
      ・UnrarSetUnicodeModeを実装。
      ・内部的にUTF-16で動作する様に変更。
      ・ユニコード文字を含むパスワードの書庫が開けない不具合を修正。
      ・x64でビルド可能な様に修正(unrar64j.dll)
      ・以下の64ビット整数値の取得API関数を追加。
        UnrarGetArcFileSizeEx
        UnrarGetArcOriginalSizeEx
        UnrarGetArcCompressedSizeEx
        UnrarGetOriginalSizeEx
        UnrarGetCompressedSizeEx

