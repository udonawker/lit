#include "gtest/gtest.h"
#include "sample.h"

namespace {//}

}  // namespace
