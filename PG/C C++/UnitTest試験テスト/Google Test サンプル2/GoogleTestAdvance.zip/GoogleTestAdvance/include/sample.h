#ifndef _SAMPLE_H_
#define _SAMPLE_H_

class Sample {
public:
    int Add(int lhs, int rhs) const;
    bool IsPrime(int num) const;
    
};

#endif // _SAMPLE_H_
