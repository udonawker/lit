#include "yuv2bmp.h"
#include <stdio.h>

int main(int argc, char* argv[])
{
    int result = 0;
    result = yuv2bmpfile(YUV_NV12, NULL, 0, 0, NULL);
}

